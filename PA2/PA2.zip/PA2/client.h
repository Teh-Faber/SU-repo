#pragma once
#include <QCoreApplication>
#include <QtSql>


class client{

public:

    client();

    int initiateTasks();

    int printTask();

    int addTask();

};




